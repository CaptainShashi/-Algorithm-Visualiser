# Algorithms
Bubble Sort
Quick Sort
DFS
Dijkstra
Prerequisite
Basic coding knowledge....

Some concept about data structure and algorithm.


Mathematices

Words about this project
# Bubble Sort
Bubble Sort is simple sorting algorithm. It is slow sorting alogithm .It used loop for sorting. This algorithm used loop so Time Complexity is high.

And Degree of Polynomial :- 2

Time Complexity is O(n^2) .

Time Complexity is n^2 because here I used Two iterations .

Quick Sort
Quick Sort is divide and conquer algorithms. Basically It has a pivot index . Using the pivot index it apply recursion . As, It is use recursion so it's time complexity will reduce

Time Complexity is O(n log n)

DFS
DFS is searching technique in a Graph . DFS means Depth first search. In this technique search will happen in depth of tree if seaching node is found then search is complete but id searching node is not found . it will backtrack .


Dijkstra
Dijkstra is very popular algorithms. It found the sortest path between two nodes . It works in weight grarph. To find the sortest path we can use adjecency matrix or adjecency list . Here I use adjecency List 
